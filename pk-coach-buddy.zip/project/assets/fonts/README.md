# Font Files

This directory contains the Inter font family used in the application.

The following font weights are included:
- Inter-Regular.ttf
- Inter-Medium.ttf
- Inter-SemiBold.ttf
- Inter-Bold.ttf

These fonts need to be downloaded and placed in this directory.

You can download the Inter font family from Google Fonts:
https://fonts.google.com/specimen/Inter